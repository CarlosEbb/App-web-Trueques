@extends('layouts.app')

@section('content')
 

 {{$categoria->nombre}} <br>
 {{$categoria->descripcion}}

@endsection