<nav id="sidebar">
  {{-- <div id="dismiss">
      <i class="fas fa-arrow-left"></i>
  </div> --}}

  <div class="sidebar-header text-center">
      <img src="{{asset('img/Logo.png')}}" alt="">
  </div>

  <ul class="list-unstyled components">
      <li class="">
          <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">Home 1</a>
      </li>
      <li>
          <a href="#">Home 2</a>
      </li>
      <li>
          <a href="#">Home 3</a>
      </li>
      <li>
          <a href="#">Home 4</a>
      </li>
  </ul>
</nav>