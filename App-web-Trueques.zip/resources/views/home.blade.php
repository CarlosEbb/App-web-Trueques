@extends('layouts.admin')
@section('content')
    <div class="container-fluid">
        <h2>Admin</h2>
    </div>
@endsection

