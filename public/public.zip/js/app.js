document
    .querySelector(".btn-menu-buscar")
    .addEventListener("click", function () {
        document.querySelector(".menu-buscar").classList.toggle("active-menu");
    });
