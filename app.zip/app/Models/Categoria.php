<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    use HasFactory;

    protected $table ='categorias';

    protected $fillable = [
        'nombre',
        'descripcion',
        'foto',
        'icon',
    ];

    public function productos()
    {
        return $this->hasMany(Producto::class, 'categoria_id');
    }

    public function subCategoria()
    {
        return $this->hasMany(SubCategoria::class, 'categoria_id');
    }
}
